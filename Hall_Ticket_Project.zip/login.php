<?php
session_start();

$servername = "localhost:3306//";
$username = "afroz";
$password = "Afroz00918";
$dbname = "exam_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['login'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                $_SESSION['username'] = $username;
                header("Location: student_registration.php");
                exit();
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "No user found with that username.";
        }
    } elseif (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        header("Location: login.php");
        exit();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #A9A9A9;
            padding: 10px;
        }
        h2 {
            text-align: center;
        }
        .login-form {
            width:500px;
            height:auto;
            background: #fff;
            margin-left:200px;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 50px rgba(0,0,0,0.9);
        }
        .login-form input[type="text"],
        .login-form input[type="password"],
        .login-form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }
        .login-form input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        .login-form input[type="submit"]:hover {
            background-color: #45a049;
        }
        .login-form p {
            margin-top: 10px;
        }
        .logged-in-message {
            background: #f0f0f0;
            padding: 10px;
            border: 1px solid #ccc;
            margin-top: 20px;
            text-align: center;
        }
        .logged-in-message a {
            color: #333;
            text-decoration: none;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="login-form">
    <h2>Login</h2>
        <?php if (!isset($_SESSION['username'])): ?>
            <form method="post" action="">
                Student ID: <input type="text" name="username" required><br>
                Password: <input type="password" name="password" required><br>
                <input type="submit" name="login" value="Login">
            </form>
            <p>New Student? <a href="signup.php">Sign Up</a></p>
            <p>Forgot your password? <a href="forgot_password.php">Click here</a></p>
        <?php else: ?>
            <div class="logged-in-message">
                <p>You are logged in as <?php echo $_SESSION['username']; ?></p>
                <form method="post" action="">
                    <input type="submit" name="logout" value="Logout">
                </form>
                <p><a href="student_registration.php">Go to Student Registration</a></p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
