<?php
$servername = "localhost:3306//";
$username = "afroz";
$password = "Afroz00918";
$dbname = "exam_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_GET['student_id'];
$sql = "SELECT * FROM students WHERE student_id = '$student_id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    echo "No student found.";
    exit();
}

$sql = "SELECT * FROM subjects WHERE branch = '{$student['branch']}'";
$subjects = $conn->query($sql);

if ($subjects->num_rows > 0) {
    $subject_details = $subjects->fetch_all(MYSQLI_ASSOC);
} else {
    echo "No subjects found for this branch.";
    exit();
}
$exam_instructions = [
    "Please arrive at the exam hall 30 minutes before the scheduled time.",
    "Ensure you have your hall ticket and a valid ID with you.",
    "Mobile phones and any electronic devices are strictly prohibited in the exam hall.",
    "Listen carefully to all instructions given by the invigilator.",
    "Do not leave the exam hall until you are permitted to do so."
];
$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title><h2>Hall Ticket</h2></title>
    <style>
        .ticket {
            width: 700px;
            margin: 0 auto;
            border: 1px solid #000;
            padding: 20px;
            text-align: center;
        }
        .ticket h1 {
            margin-top: 0;
        }
        .ticket img {
            width: 100px;
            height: 100px;
        }
        .details-photo{
            display:flex;
        }
        .details{
            position: relative;
            width:60%;
        }
        .photo{
            position: right;
            width:30%;
        }
        .signature-box {
            width: 75px;
            height: 15px;
            border: 1px solid #000;
            margin-left: 67px;
            
        }.instruction {
            background-color: lightblue; /* This is just for visual confirmation */
        }

    </style>
    <script>
        function printTicket() {
            window.print();
        }
    </script>
</head>
<body>
    <div class="ticket">
        <h1> Hall Ticket</h1>
        <div class=details-photo>
            <div class=details>
                <br>
                <p><strong>Student ID:</strong> <?php echo $student['student_id']; ?></p>
                <p><strong>Name:</strong> <?php echo $student['name']; ?></p>
                <p><strong>Branch:</strong> <?php echo $student['branch']; ?></p>
                <p><strong>Year-Sem:</strong> <?php echo $student['year']; ?></p>
            </div>
            <div class=photo>
                <p><img src="<?php echo htmlspecialchars($student['photo']); ?>" alt="Student Photo"></p>
                <div class="signature-box"></div>
                <p>Signature</p>
            </div>
        </div>
        
        <h2>Exam Details</h2>
        <table border="1" cellpadding="5" cellspacing="0" align="center">
            <tr>
                <th>Subject Code</th>
                <th>Subject</th>
                <th>Date</th>
                <th>Time</th>
                <th>Signature</th>
            </tr>
            <?php foreach ($subject_details as $subject) { ?>
                <tr>
                    <td><?php echo $subject['subject_code']; ?></td>
                    <td><?php echo $subject['subject_name']; ?></td>
                    <td><?php echo $subject['exam_date']; ?></td>
                    <td><?php echo $subject['exam_time']; ?></td>
                    <td><?php echo $subject['signature']; ?></td>
                </tr>
            <?php } ?>
        </table>
        <div class="instructions">
            <h3 >Instructions for students</h3>
            <p class="instruction" style="text-align: left;">
            <ul>
                <?php foreach ($exam_instructions as $instruction) { ?>
                <li><?php echo $instruction; ?></li>
                <?php } ?>
            </ul>
            </p>
        </div>
        <br><button onclick="printTicket()">Print Hall Ticket</button>
    </div>
</body>
</html>
