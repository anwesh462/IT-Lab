<!-- pass_verify.php -->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Result</title>
<link rel="stylesheet" href="style.css"> <!-- Optional: Your custom CSS -->
</head>
<body>
<div class="container">
<?php
session_start();
include("db_conn.php"); // Include your database connection script

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $id = $_POST['id'];
    $password = $_POST['password'];
    
    // Use prepared statement to prevent SQL injection
    $query = "SELECT * FROM project WHERE id = '$id' AND password = '$password'";
    $result = mysqli_query($con, $query);
    
    if (mysqli_num_rows($result) == 1) {
        // Fetch user data
        $row = mysqli_fetch_assoc($result);
        
        // Display user details
        echo '<div class="output-container">';
        echo '<p class="success-message">Login successful</p>';
        echo "<div class='user-details'>";
        echo "<p><strong>ID:</strong> ".$row['id']."</p>";
        echo "<p><strong>Name:</strong> ".$row['name']."</p>";
        echo "<p><strong>Password:</strong> ".$row['password']."</p>";
        echo "</div>";
        echo '</div>';
    } else {
        // Invalid credentials
        echo "<p class='error-message'>Invalid ID or password</p>";
    }
} else {
    // Handle invalid request method
    echo "<p class='error-message'>Invalid request</p>";
}

mysqli_close($con); // Close the database connection
?>
</div>
</body>
</html>
