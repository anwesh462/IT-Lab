<?php
$servername = "localhost";
$username = "afroz";
$password = "Afroz00918";
$dbname = "project";

// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
} else {
    echo "Connected successfully"; // Debugging statement
}
?>
