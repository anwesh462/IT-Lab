<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost:3306//";
$username = "afroz";
$password = "Afroz00918";
$dbname = "exam_system";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_POST['student_id'];
    $name = $_POST['name'];
    $branch = $_POST['branch'];
    $year = $_POST['year'];
    $photo = "uploads/" . basename($_FILES["photo"]["name"]);
    move_uploaded_file($_FILES["photo"]["tmp_name"], $photo);

    $sql = "INSERT INTO students (student_id, name, branch,year, photo) VALUES ('$student_id', '$name', '$branch','$year', '$photo')";

    if ($conn->query($sql) === TRUE) {
        header("Location: generate_hallticket.php?student_id=$student_id");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Exam Registration</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #A9A9A9;
            padding: 20px;
        }

        h2 {
            text-align:center;
        }

        form {
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 20px;
            max-width: 400px;
            margin: 0 auto;
            border-radius: 5px;
        }

        input[type="text"],
        input[type="file"] {
            width: calc(100% - 12px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Exam Registration</h2>
    <form method="post" action="" enctype="multipart/form-data">
        Student ID: <input type="text" name="student_id" required><br>
        Name: <input type="text" name="name" required><br>
        Branch: <input type="text" name="branch" required><br>
        Year: <input type="text" name="year" required><br>
        Photo: <input type="file" name="photo" required><br>
        <input type="submit" value="Register">
    </form>
</body>
</html>
